#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
编码工具模块

提供文本编码检测、乱码修复等功能

作者: News Aggregator System
日期: 2025-12-25
"""

import re
from typing import Optional, List, Tuple
from loguru import logger


def detect_encoding(data: bytes) -> Tuple[str, float]:
    """
    检测字节数据的编码
    
    Args:
        data: 字节数据
        
    Returns:
        (encoding, confidence): 编码名称和置信度
    """
    # 尝试常见编码
    encodings = [
        ('utf-8', 0.9),
        ('gbk', 0.7),
        ('gb2312', 0.6),
        ('gb18030', 0.7),
        ('utf-16', 0.5),
        ('latin-1', 0.3),  # 总是能解码，作为后备
    ]
    
    for encoding, base_confidence in encodings:
        try:
            decoded = data.decode(encoding)
            # 计算置信度
            chinese_ratio = sum(1 for c in decoded if '\u4e00' <= c <= '\u9fff') / max(len(decoded), 1)
            confidence = base_confidence + chinese_ratio * 0.1
            
            if chinese_ratio > 0.1 or encoding == 'utf-8':
                return encoding, min(confidence, 1.0)
        except UnicodeDecodeError:
            continue
    
    return 'latin-1', 0.1


def fix_mojibake(text: str, source_encoding: str = 'utf-8') -> str:
    """
    修复乱码(Mojibake)
    
    当UTF-8文本被错误地用Latin-1/ISO-8859-1解析时，会产生乱码。
    此函数尝试还原原始文本。
    
    Args:
        text: 可能包含乱码的文本
        source_encoding: 原始编码（默认UTF-8）
        
    Returns:
        修复后的文本
    """
    if not text:
        return ""
    
    # 检测是否是乱码 (包含典型的Latin-1范围的特殊字符)
    mojibake_chars = set('ãäåæçèéêëìíîïðñòóôõöøùúûüýþÿ'
                        'ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖ×ØÙÚÛÜÝÞß'
                        'àáâ')
    
    # 如果文本中有大量Latin-1高位字符，可能是乱码
    high_char_count = sum(1 for c in text if c in mojibake_chars or 0x80 <= ord(c) < 0x100)
    if high_char_count < len(text) * 0.1:
        return text
    
    # 尝试检测是否所有字符都在Latin-1范围内
    try:
        raw_bytes = text.encode('latin-1')
    except UnicodeEncodeError:
        return text
    
    # 尝试将这些字节按目标编码解码
    try:
        fixed = raw_bytes.decode(source_encoding)
        if any('\u4e00' <= c <= '\u9fff' for c in fixed):
            return fixed
    except UnicodeDecodeError:
        pass
    
    # 宽松模式
    try:
        fixed = raw_bytes.decode(source_encoding, errors='ignore')
        if fixed and any('\u4e00' <= c <= '\u9fff' for c in fixed):
            return fixed
    except Exception:
        pass
    
    # 尝试其他编码
    for encoding in ['gbk', 'gb2312', 'gb18030']:
        try:
            fixed = raw_bytes.decode(encoding)
            if any('\u4e00' <= c <= '\u9fff' for c in fixed):
                return fixed
        except Exception:
            continue
    
    return text


def decode_with_fallback(data: bytes, preferred_encoding: str = 'utf-8') -> str:
    """
    使用后备编码解码字节数据
    
    Args:
        data: 字节数据
        preferred_encoding: 首选编码
        
    Returns:
        解码后的文本
    """
    encodings = [preferred_encoding, 'utf-8', 'gbk', 'gb18030', 'latin-1']
    seen = set()
    
    for encoding in encodings:
        if encoding in seen:
            continue
        seen.add(encoding)
        
        try:
            decoded = data.decode(encoding)
            # 验证解码结果
            if any('\u4e00' <= c <= '\u9fff' for c in decoded[:500]):
                return decoded
        except UnicodeDecodeError:
            continue
    
    # 最后的回退
    return data.decode('utf-8', errors='replace')


def clean_text(text: str) -> str:
    """
    清理文本
    
    - 修复乱码
    - 移除HTML标签
    - 规范化空白
    
    Args:
        text: 原始文本
        
    Returns:
        清理后的文本
    """
    if not text:
        return ""
    
    # 修复乱码
    text = fix_mojibake(text)
    
    # 移除HTML标签
    text = re.sub(r'<[^>]+>', '', text)
    
    # 规范化空白
    text = re.sub(r'\s+', ' ', text)
    
    return text.strip()


def normalize_unicode(text: str) -> str:
    """
    规范化Unicode文本
    
    - 解码Unicode转义序列
    - 规范化全角/半角字符
    
    Args:
        text: 原始文本
        
    Returns:
        规范化后的文本
    """
    if not text:
        return ""
    
    # 解码 \\uXXXX 转义
    if '\\u' in text:
        try:
            text = text.encode('utf-8').decode('unicode_escape')
        except Exception:
            pass
    
    return text


# 测试
if __name__ == "__main__":
    # 测试乱码修复
    correct = '【昆山深化两岸产业合作试验区】'
    mojibake = correct.encode('utf-8').decode('latin-1')
    
    print(f"原文: {correct}")
    print(f"乱码: {mojibake}")
    print(f"修复: {fix_mojibake(mojibake)}")
    
    # 测试编码检测
    data = "这是中文".encode('utf-8')
    encoding, confidence = detect_encoding(data)
    print(f"\n编码检测: {encoding} (置信度: {confidence:.2f})")
    
    data_gbk = "这是中文".encode('gbk')
    encoding, confidence = detect_encoding(data_gbk)
    print(f"GBK编码检测: {encoding} (置信度: {confidence:.2f})")
